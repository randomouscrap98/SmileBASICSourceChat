using System;

namespace Example1
{
  internal class TextMessage
  {
    public uint?  user_id;
    public string name;
    public string type;
    public string message;
  }
}
