using System;
using System.Linq;
using System.Collections.Generic;

namespace MyExtensions
{
   public class Configuration
   {
      private Dictionary<string, Dictionary<string, object>> values = new Dictionary<string, Dictionary<string, object>>();


   }

   public class ConfigurationValue
   {
      private object value;
      private Type type;

      public ConfigurationValue(double value)
      {

      }

      //private void 
   }
}