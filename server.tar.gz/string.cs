using System;

namespace MyHelper
{
   public class StringHelper
   {

   }
}
