using System;
using ModuleSystem;

namespace ModulePackage1
{
//   public class MeModule : Module
//   {
//      public MeModule()
//      {
//         //commands.AddRange(
//      }
//   }
}