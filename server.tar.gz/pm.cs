using System;
using System.Collections.Generic;
using System.Linq;

namespace ChatServer
{
   public class PMRoom
   {
      public readonly List<string> Users;
      //public
   }
}